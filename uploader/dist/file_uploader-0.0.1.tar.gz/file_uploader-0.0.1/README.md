Please read the following instructions carefully:

Installation

Use pip to install the dist

Requirements

Install google-cloud-storage, build, boto3 and configparser, along with required packages if not already installed

Config File Changes
1. Please provide proper directory paths, proper s3 and google blob/bucket paths
2. To make changes in the type of extensions to be uploaded, please make the changes in the FILE_EXTENSIONS section of config.properties
3. Please make sure the config file paths and the file itself is syntactically correct before execution